from ndinterval.ndinterval import ndinterval
from ndinterval.utils import *